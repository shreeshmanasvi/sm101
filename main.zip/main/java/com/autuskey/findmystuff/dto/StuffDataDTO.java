package com.autuskey.findmystuff.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class StuffDataDTO implements Serializable {

    private String id;
    private String stuffname;
    private String stuffplace;
    private String imagename;
    private String stufftags;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     *
     * @return
     * The id
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * The id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     * The stuffname
     */
    public String getStuffname() {
        return stuffname;
    }

    /**
     *
     * @param stuffname
     * The stuffname
     */
    public void setStuffname(String stuffname) {
        this.stuffname = stuffname;
    }

    /**
     *
     * @return
     * The stuffplace
     */
    public String getStuffplace() {
        return stuffplace;
    }

    /**
     *
     * @param stuffplace
     * The stuffplace
     */
    public void setStuffplace(String stuffplace) {
        this.stuffplace = stuffplace;
    }

    /**
     *
     * @return
     * The imagename
     */
    public String getImagename() {
        return imagename;
    }

    /**
     *
     * @param imagename
     * The imagename
     */
    public void setImagename(String imagename) {
        this.imagename = imagename;
    }

    /**
     *
     * @return
     * The stufftags
     */
    public String getStufftags() {
        return stufftags;
    }

    /**
     *
     * @param stufftags
     * The stufftags
     */
    public void setStufftags(String stufftags) {
        this.stufftags = stufftags;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}