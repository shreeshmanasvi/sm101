package com.autuskey.findmystuff;

/**
 * Created by SM on 20/04/2016.
 */

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.autuskey.findmystuff.dto.StuffDataDTO;

import java.io.File;
import java.util.ArrayList;


class CustomListAdapter extends BaseAdapter {

    private Context mContext;

    private ArrayList<StuffDataDTO> stuffDataDTOArrayList = new ArrayList<StuffDataDTO>();
    private String feedType = "";

    public CustomListAdapter(Context context,ArrayList<StuffDataDTO> dataDTOArrayList) {
        this.mContext = context;
       this.stuffDataDTOArrayList = dataDTOArrayList;
    }

    @Override
    public int getCount() {
        int size = 0;
        if (null != stuffDataDTOArrayList) {
            size = stuffDataDTOArrayList.size();
        }
        return size;
    }

    @Override
    public Object getItem(int position) {
        return stuffDataDTOArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return stuffDataDTOArrayList.indexOf(getItem(position));
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View vi = convertView;
        final ViewHolder holder;
        LayoutInflater mInflater = (LayoutInflater) mContext
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {
            vi = mInflater.inflate(R.layout.custom_list, null);
            holder = new ViewHolder();
            holder.cl_stuff_nameTextView = (TextView) vi
                    .findViewById(R.id.cl_stuff_name);
            holder.cl_stuff_placeTextView = (TextView) vi.findViewById(R.id.cl_stuff_place);
           /* *//** To Underline the Feed Title *//*
            holder.cl_stuff_tagsTextView.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);*/
            holder.cl_stuff_tagsTextView = (TextView) vi
                    .findViewById(R.id.cl_stuff_tags);
            holder.getCl_image_view = (ImageView) vi.findViewById(R.id.cl_image_view);
            holder.cl_del_Button = (Button) vi.findViewById(R.id.cl_del_btn);

            holder.cl_del_Button.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    Toast.makeText(mContext, "Delete icon click ",Toast.LENGTH_SHORT).show();
                }
            });
            vi.setTag(holder);

        } else {
            holder = (ViewHolder) vi.getTag();
        }
        StuffDataDTO stuffDataDTO = (StuffDataDTO) stuffDataDTOArrayList
                .get(position);

        holder.cl_stuff_nameTextView.setText(stuffDataDTO.getStuffname());
        holder.cl_stuff_placeTextView.setText(stuffDataDTO.getStuffplace());
        holder.cl_stuff_tagsTextView.setText(stuffDataDTO.getStufftags());

        File file = new File(stuffDataDTO.getImagename());
        Bitmap bmImg = BitmapFactory.decodeFile(file.getAbsolutePath());
        holder.getCl_image_view.setImageBitmap(bmImg);

        return vi;
    }


    public static class ViewHolder {
        public TextView cl_stuff_nameTextView;
        public TextView cl_stuff_placeTextView;
        public TextView cl_stuff_tagsTextView;
        public ImageView getCl_image_view;
        public Button cl_del_Button;
        public ViewHolder() {
            super();
            // TODO Auto-generated constructor stub
        }
    }

}