package com.autuskey.findmystuff;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import com.autuskey.findmystuff.dto.StuffDataDTO;

import java.util.ArrayList;

/**
 * Created by SM on 02-Feb-2016 002.
 */
public class MyDBHandler extends SQLiteOpenHelper{
    public static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "stuffs.db";
    public static final String TABLE_STUFFS  = "stuffs";
    public static final String COLUMN_ID = "id ";
    public static final String COLUMN_STUFFNAME = "stuffname";
    public static final String COLUMN_STUFFPLACE = "stuffplace";
    public static final String COLUMN_IMAGENAME = "imagename";
    public static final String COLUMN_STUFFTAGS = "stufftags";

    //constructor
    public MyDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //override onCreate method for creating DB
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE IF NOT EXISTS " + TABLE_STUFFS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT " + ", " +
                COLUMN_STUFFNAME + " TEXT " + ", " +
                COLUMN_STUFFPLACE + " TEXT " + ", " +
                COLUMN_IMAGENAME + " TEXT " + ", " +
                COLUMN_STUFFTAGS + " TEXT " +
                ");";
        db.execSQL(query);
    }

    //override onupgrade method for dropping old DB and creating fresh DB by calling onCreate explicitly
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS " + TABLE_STUFFS + ";";
        db.execSQL(query);
        onCreate(db);
    }

    //add record to stuffs table
    public void addStuff(Stuffs stuff){
        ContentValues values = new ContentValues();
        values.put(COLUMN_STUFFNAME, stuff.get_stuffName());
        values.put(COLUMN_STUFFPLACE, stuff.get_stuffPlace());
        values.put(COLUMN_IMAGENAME, stuff.get_imageName());
        values.put(COLUMN_STUFFTAGS, stuff.get_stuffTags());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_STUFFS, null, values);
        db.close();
    }

    //delete stuff from database
    public void deleteStuff(String stuffName){
        String query = "DELETE FROM " + TABLE_STUFFS + " WHERE " + COLUMN_STUFFNAME + " = " + "\"" + stuffName + "\" ;";
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(query);
    }

    //print database
    public String databaseToString(){
        String returnString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT `stuffname`, `stuffplace`, `imagename`, `stufftags` FROM " + TABLE_STUFFS + " WHERE 1 ORDER BY id DESC;";

        //Cursor pointing to a location in result
        Cursor c = db.rawQuery(query, null);
        //move to first record in result
        c.moveToFirst();
        while (!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("stuffname")) != null){
                returnString += c.getString(c.getColumnIndex("stuffname"));
                returnString += " - ";
                returnString += c.getString(c.getColumnIndex("stuffplace"));
                returnString += " - image : ";
                returnString += c.getString(c.getColumnIndex("imagename"));
                returnString += " - tags : ";
                returnString += c.getString(c.getColumnIndex("stufftags"));
                returnString += ",\n";
            }
            //move to next record
            c.moveToNext();
        }
        db.close();
        return returnString;
    }

    //get database result to object
    public String databaseToObject(){
        String returnString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT `stuffname`, `stuffplace`, `imagename`, `stufftags` FROM " + TABLE_STUFFS + " WHERE 1 ORDER BY id DESC;";

        //Cursor pointing to a location in result
        Cursor c = db.rawQuery(query, null);
        //move to first record in result
        c.moveToFirst();
        while (!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("stuffname")) != null){
                returnString += c.getString(c.getColumnIndex("stuffname"));
                returnString += ",\n ";
                returnString += c.getString(c.getColumnIndex("stuffplace"));
                returnString += ",\n ";
                returnString += c.getString(c.getColumnIndex("imagename"));
                returnString += ",\n ";
                returnString += c.getString(c.getColumnIndex("stufftags"));
                returnString += ",\n";
            }
            //move to next record
            c.moveToNext();
        }
        db.close();
        return returnString;
    }

    /**
     *@return list of stuff data form db
      */
    public ArrayList<StuffDataDTO> getStuffDataFromDB(){
        ArrayList<StuffDataDTO> stuffDataDTOArrayList = new ArrayList<StuffDataDTO>();
        String returnString = "";
        String path = Environment.getExternalStorageDirectory().toString();
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT `stuffname`, `stuffplace`, `imagename`, `stufftags` FROM " + TABLE_STUFFS + " WHERE 1 ORDER BY id DESC;";
        //Cursor pointing to a location in result
        Cursor c = db.rawQuery(query, null);
        //move to first record in result
        c.moveToFirst();
        while (!c.isAfterLast()){
            if(c.getString(c.getColumnIndex("stuffname")) != null){
                StuffDataDTO dataDTO = new StuffDataDTO();
                dataDTO.setId(c.getString(c.getColumnIndex("stuffname")));
                dataDTO.setStuffname(c.getString(c.getColumnIndex("stuffname")));
                dataDTO.setStuffplace(c.getString(c.getColumnIndex("stuffplace")));
                dataDTO.setImagename(path+"/Pictures/findmystuff/"+(c.getString(c.getColumnIndex("imagename"))).replace(" ",","));
                dataDTO.setStufftags(c.getString(c.getColumnIndex("stufftags")));
                stuffDataDTOArrayList.add(dataDTO);
            }
            //move to next record
            c.moveToNext();
        }
        db.close();
        return stuffDataDTOArrayList;
    }
}
